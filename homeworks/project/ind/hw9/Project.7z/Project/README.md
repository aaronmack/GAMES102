Pre-request: OpenMesh
(Compiled in macOS, linux should be also ok)
then run the following command:
git clone https://github.com/libigl/libigl.git
mkdir build
cd build
cmake ..
make
./HW9
‘1’键简化网格 ‘2’键恢复上一步