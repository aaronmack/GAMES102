# notice
REF FROM: 谢聪

# preface
cd Project\extern
git clone --recursive https://github.com/pmp-library/pmp-library.git

# build
mkdir build
cd build
cmake -G "Visual Studio 16 2019" ..

# modified
* **FOR CAN BE RUNNING ON WINDOWS**

FROM: L_triplets.push_back({v.idx(), v.idx(), -ww});		
TO: L_triplets.push_back({static_cast<ptrdiff_t>(v.idx()), static_cast<ptrdiff_t>(v.idx()), -ww});

* https://github.com/tensorflow/quantum/pull/219
* https://github.com/tensorflow/quantum/issues/217